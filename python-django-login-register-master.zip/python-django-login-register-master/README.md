# python-django-login-register
Basic login and registration app using python and django. Includes validation rules for user input. Users are created and saved in an SQLite database. Displays a simple welcome page to confirm successful registration or login. 
